<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-6">
    <h1 class="text-2xl font-bold mb-6">Patient Details</h1>

    <div class="mb-6 bg-white p-6 rounded shadow">
        <h2 class="text-xl font-semibold mb-4">Patient Information</h2>
        <p><strong>Name:</strong> <?php echo e($patient->name); ?></p>
        <p><strong>Birth Date:</strong> <?php echo e($patient->birth_date); ?></p>
        <p><strong>Gender:</strong> <?php echo e(ucfirst($patient->gender)); ?></p>
        <p><strong>Address:</strong> <?php echo e($patient->address); ?></p>
        <p><strong>Region:</strong> <?php echo e($patient->region ? $patient->region->province . ' - ' . $patient->region->district : '-'); ?></p>
        <p><strong>Phone:</strong> <?php echo e($patient->phone); ?></p>
        <p><strong>Email:</strong> <?php echo e($patient->email); ?></p>
    </div>

    <div class="mb-6 bg-white p-6 rounded shadow">
        <h2 class="text-xl font-semibold mb-4">Visits</h2>
        <?php if($patient->visits->isEmpty()): ?>
            <p>No visits found for this patient.</p>
        <?php else: ?>
            <table class="min-w-full bg-white rounded shadow">
                <thead>
                    <tr>
                        <th class="py-2 px-4 border-b">Visit Date</th>
                        <th class="py-2 px-4 border-b">Visit Type</th>
                        <th class="py-2 px-4 border-b">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $patient->visits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="py-2 px-4 border-b"><?php echo e($visit->visit_date); ?></td>
                        <td class="py-2 px-4 border-b"><?php echo e($visit->visit_type); ?></td>
                        <td class="py-2 px-4 border-b">
                            <a href="<?php echo e(route('visits.show', $visit)); ?>" class="text-blue-600 hover:underline">View</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <a href="<?php echo e(route('patient_registrations.index')); ?>" class="text-gray-600 hover:underline">Back to Patient Registrations</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /project/sandbox/user-workspace/resources/views/patient_registrations/show.blade.php ENDPATH**/ ?>