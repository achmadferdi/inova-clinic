<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-6">
    <h1 class="text-2xl font-bold mb-6">Add New Payment</h1>

    <?php if($errors->any()): ?>
        <div class="mb-4 p-4 bg-red-100 text-red-700 rounded">
            <ul class="list-disc list-inside">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('payments.store')); ?>" method="POST" class="max-w-md">
        <?php echo csrf_field(); ?>
        <div class="mb-4">
            <label for="visit_id" class="block text-gray-700 font-medium mb-2">Visit</label>
            <select name="visit_id" id="visit_id" required
                class="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="">Select Visit</option>
                <?php $__currentLoopData = $visits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($visit->id); ?>">
                        <?php echo e($visit->id); ?> - <?php echo e($visit->patient->name); ?> (<?php echo e($visit->visit_date); ?>)
                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="mb-4">
            <label for="amount" class="block text-gray-700 font-medium mb-2">Amount</label>
            <input type="number" step="0.01" name="amount" id="amount" value="<?php echo e(old('amount')); ?>" required
                class="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500" />
        </div>
        <div class="mb-4">
            <label for="payment_date" class="block text-gray-700 font-medium mb-2">Payment Date</label>
            <input type="date" name="payment_date" id="payment_date" value="<?php echo e(old('payment_date')); ?>" required
                class="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500" />
        </div>
        <div class="mb-4">
            <label for="payment_method" class="block text-gray-700 font-medium mb-2">Payment Method</label>
            <input type="text" name="payment_method" id="payment_method" value="<?php echo e(old('payment_method')); ?>"
                class="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500" />
        </div>
        <button type="submit"
            class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition duration-200">Save</button>
        <a href="<?php echo e(route('payments.index')); ?>" class="ml-4 text-gray-600 hover:underline">Cancel</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /project/sandbox/user-workspace/resources/views/payments/create.blade.php ENDPATH**/ ?>